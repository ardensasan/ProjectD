#ifndef CHICKEN_H
#define CHICKEN_H
class Chicken
{
public:
private:
};
#endif

