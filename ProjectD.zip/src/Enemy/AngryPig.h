#ifndef ANGRYPIG_H
#define ANGRYPIG_H
class AngryPig
{
public:
private:
};

#endif
